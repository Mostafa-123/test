<?php

namespace App\Http\classes;

trait admin
{

}
